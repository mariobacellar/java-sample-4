/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package smtptester;

/**
 *
 * @author mateo
 */
public class SMTPTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SMTPGui gui = new SMTPGui();
        gui.setVisible(true);
    }
}
